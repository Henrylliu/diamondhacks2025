(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/app_globals_73c37791.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_26a3c7b5._.js",
    "static/chunks/node_modules_next_dist_ade45ae5._.js"
  ],
  "source": "dynamic"
});
