// app/api/math_questions/route.ts
import clientPromise from "@/lib/mongodb";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const client = await clientPromise;
    const db = client.db("sample_mflix");
    const data = await db.collection("math_questions").find({}).toArray();

    return NextResponse.json(data);
  } catch (err: any) {
    console.error("ERROR FETCHING:", err);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}